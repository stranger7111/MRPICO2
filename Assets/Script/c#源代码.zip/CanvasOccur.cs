using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit;
[RequireComponent(typeof(XRSimpleInteractable))]
public class CanvasOccur : MonoBehaviour
{
    public Canvas targetcanvas;
    public XRSimpleInteractable interactable;
    bool isActive;
    // Start is called before the first frame update
    void Start()
    {
        isActive = false;
        interactable =GetComponent<XRSimpleInteractable>();
        interactable.selectEntered.AddListener(OnSelectEnter);
        if (targetcanvas!= null)
        {
            targetcanvas.gameObject.SetActive(isActive);
        }
    }

    private void OnSelectEnter(SelectEnterEventArgs args)
    {
        isActive = !isActive;
        if (targetcanvas != null)
        {
            targetcanvas.gameObject.SetActive(isActive);
        }
    }
    private void OnDestroy()
    {
        if (interactable != null)
        {
            interactable.selectEntered.RemoveListener(OnSelectEnter);
        }
    }
    // Update is called once per frame

}

