using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR.Interaction.Toolkit;

[RequireComponent(typeof(XRSimpleInteractable))]
public class EntranceButton : MonoBehaviour // ��������
{
    public Animator buttonAnimator1;
    private bool isAnimating;
    private XRSimpleInteractable interactable;
    AnimatorStateInfo stateInfo;
    private void Start()
    {
        interactable = GetComponent<XRSimpleInteractable>();
        interactable.selectEntered.AddListener(OnButtonClicked);
    }

    private void Update()
    {
        // ������⶯��״̬
        
            stateInfo = buttonAnimator1.GetCurrentAnimatorStateInfo(0);
            if (stateInfo.IsName("Scene") && stateInfo.normalizedTime >=0.99f)
            {
                Debug.Log("��������");
                SceneManager.LoadScene(2);
               
            }
        
    }

    public void OnButtonClicked(SelectEnterEventArgs args)
    {

        if (buttonAnimator1 != null)
        {
            buttonAnimator1.SetTrigger("Click"); // ȷ�������������� Animator ��һ��
          // ��Ƕ�����ʼ
            Debug.Log("��������");
        }
    }

    private void OnDestroy()
    {
        if (interactable != null)
        {
            interactable.selectEntered.RemoveListener(OnButtonClicked);
        }
    }
}
