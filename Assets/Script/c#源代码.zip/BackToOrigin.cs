using System.Collections;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine;
public class BackToOrigin: XRGrabInteractable
{
    private Vector3 originalPosition;
    private Quaternion originalRotation;

    protected override void Awake()
    {
        base.Awake();
        // �����ʼλ��
        originalPosition = transform.position;
        originalRotation = transform.rotation;
    }

    protected override void OnSelectExited(SelectExitEventArgs args)
    {
        base.OnSelectExited(args);
        // �ͷ�ʱ�ָ�λ��
        ResetToOriginalPosition();
    }

    private void ResetToOriginalPosition()
    {
        // �ر�����ģ���Ա����ͻ
      // GetComponent<Rigidbody>().isKinematic = true;
        transform.position = originalPosition;
        transform.rotation = originalRotation;
      //  GetComponent<Rigidbody>().isKinematic = false;
    }
}
