using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.UI;
public class AnimationButton : MonoBehaviour
{
   
    public XRSimpleInteractable interactable;
    public Animator ButtonAnimator;
    public Image targetImage1;
    public Image targetImage2;
    private bool isVisible ;
    private bool isActive;
    public GameObject targetObject;
    // Start is called before the first frame update
    void Start()
    {
        interactable = GetComponent<XRSimpleInteractable>();
        interactable.selectEntered.AddListener(OnButtonClicked);
        
    }

    public void OnButtonClicked(SelectEnterEventArgs args)
    {
        if (ButtonAnimator != null)
        {
            ButtonAnimator.ResetTrigger("Click"); // ������
            ButtonAnimator.SetTrigger("Click");
        }
        Toggle();
        Spawn();
    }
    // Update is called once per frame
    public void Toggle()
    {
        isVisible = !isVisible;
        targetImage1.gameObject.SetActive(isVisible);
        targetImage2.gameObject.SetActive(isVisible);
    }
    public void Spawn()
    {
        isActive = targetObject.activeSelf;
        targetObject.SetActive(!isActive);
    }

    private void OnDisable ()
    {
        Debug.Log("���������Ƴ�");
        if (interactable != null)
        {
            interactable.selectEntered.RemoveListener(OnButtonClicked);
        }
    }
}
