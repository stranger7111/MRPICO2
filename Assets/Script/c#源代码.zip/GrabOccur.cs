using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.UI;
public class GrabOccur : MonoBehaviour
{
    public XRGrabInteractable interactable;
    bool isActive;
    public Canvas  targetCanvas;
    // Start is called before the first frame update
    void Start()
    {
        interactable = GetComponent<XRGrabInteractable>();
        isActive = false;
        if (targetCanvas != null)
        {
            targetCanvas.enabled = isActive;
        }
        interactable.selectEntered.AddListener(OnClick);
        interactable.selectExited.AddListener(OnExit);
    }
    private void OnClick(SelectEnterEventArgs args)
    {
        isActive = !isActive;
        if (targetCanvas != null)
        {
            targetCanvas.enabled = isActive;
        }
    }
    private void OnExit(SelectExitEventArgs args)
    {
        isActive = !isActive;
        if (targetCanvas != null)
        {
            targetCanvas.enabled = isActive;
        }
    }
    // Update is called once per frame
    private void OnDestroy()
    {
        if (interactable != null)
        {
            interactable.selectEntered.RemoveListener(OnClick);
            interactable.selectExited.RemoveListener(OnExit);
        }
     
    }
}
