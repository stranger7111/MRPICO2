using PXR_Audio.Spatializer;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class ActiveInstrument : MonoBehaviour
{
    private XRSimpleInteractable interactable;
   public GameObject targetObject1;
    public GameObject targetObject2;
    public GameObject targetObject3;
    public Animator ani1;
    public Animator ani2;
    public Animator ani3;
    public Animator InstrumentAni;
    bool isActive;
    // Start is called before the first frame update
    private void Start()
    {
        isActive = false;
        interactable = GetComponent<XRSimpleInteractable>();
        interactable.selectEntered.AddListener(OnSelectEntered);
    }
    public void OnSelectEntered(SelectEnterEventArgs args)
    {
        isActive = !isActive;
        if (targetObject1 != null)
        {
            targetObject1.SetActive(isActive);
        }
        if (targetObject2!= null)
        {
            targetObject2.SetActive(isActive);
        }
        if (targetObject3 != null)
        {
            targetObject3.SetActive(isActive);
        }
        if (ani1 != null)
        {

            ani1.SetTrigger("Click"); // ȷ�������������� Animator ��һ��
        }
        if (ani2 != null)
        {

            ani2.SetTrigger("Click"); // ȷ�������������� Animator ��һ��
        }
        if (ani3 != null)
        {

            ani3.SetTrigger("Click"); // ȷ�������������� Animator ��һ��
        }
        if (InstrumentAni != null)
        {
            InstrumentAni.SetTrigger("Click");
        }
    }
    private void OnDestroy()
    {
        if (interactable != null)
        {
            interactable.selectEntered.RemoveListener(OnSelectEntered);
        }
    }
}
