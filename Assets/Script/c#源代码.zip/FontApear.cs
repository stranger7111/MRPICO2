using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.UI;
public class FontApear : MonoBehaviour
{
    // Start is called before the first frame update
    private XRSimpleInteractable interactable;
    public Canvas targetCanvas;
    bool isActive;
    void Start()
    {
        interactable = GetComponent<XRSimpleInteractable>();
        isActive = false;
        if (targetCanvas != null)
        {
            targetCanvas.gameObject.SetActive(isActive);
        }
        interactable.selectEntered.AddListener(OnSelected);
    }
    private void OnSelected(SelectEnterEventArgs args)
    {
        isActive = !isActive;
        targetCanvas.gameObject.SetActive(isActive);
    }
    // Update is called once per frame
    private void OnDestroy()
    {
        if (interactable != null)
        {
            interactable.selectEntered.RemoveListener(OnSelected);
        }

    }
}
