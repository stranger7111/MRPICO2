using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
[RequireComponent(typeof(Dropdown))]
public class SceneSwitcher : MonoBehaviour
{
    [SerializeField] private Dropdown sceneDropdown;// ����������˵��ϵ����������
    public Animator animator;
    // Start is called before the first frame update
    void Start()
    {
        // sceneDropdown = FindObjectOfType<Dropdown>();
        animator = GetComponent<Animator>();
        sceneDropdown =gameObject.GetComponent<Dropdown>();
       sceneDropdown.onValueChanged.AddListener(OnDropdownValueChanged);
    }

    public void OnDropdownValueChanged(int index)
    {
        if(index==0)
        {
            animator.SetTrigger("Click");
        }
       
        if (sceneDropdown != null)
        {
            SceneManager.LoadScene(index);
        }
    }
   // Update is called once per frame

}
